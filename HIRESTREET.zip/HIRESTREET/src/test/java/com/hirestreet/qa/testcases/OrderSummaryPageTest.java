package com.hirestreet.qa.testcases;

import com.hirestreet.qa.base.TestBase;

public class OrderSummaryPageTest extends TestBase {

}
