package com.hirestreet.qa.testcases;

import org.junit.Assert;
import org.testng.annotations.*;
import com.hirestreet.qa.base.TestBase;
import com.hirestreet.qa.pages.AccountPage;
import com.hirestreet.qa.pages.LoginPage;
import com.hirestreet.qa.pages.OrderPage;
import com.hirestreet.qa.pages.OrderSummaryPage;
import com.hirestreet.qa.util.TestUtil;

public class OrderPageTest extends TestBase{
	LoginPage loginPage;
	AccountPage accountPage;
	OrderPage orderPage;
	OrderSummaryPage ordersumpage;
	TestUtil testUtil = new TestUtil();
	
	public OrderPageTest(){
		super();
	}
	
	@BeforeClass
	public void setUp()
	{
		initialization();
		loginPage  = new LoginPage();
		//orderPage = new OrderPage();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		loginPage.acceptpopup();
		loginPage.ToU();
		accountPage =loginPage.login(prop.getProperty("email"), prop.getProperty("password"));
		
		orderPage = accountPage.clickOnBasketLink();
		
	}
	
	@Test(priority = 1)
	public void VerifyOrderTitleTest()
	{
		String orderTitle = orderPage.verifyTitle();
		Assert.assertEquals(orderTitle, "Your Hirestreet shopping bag | Hirestreet");
	}
	
	/*@Test(priority = 2)
	public void ClickonDiscountField()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		orderPage.clickOnDiscountField();
		orderPage.clickOnDiscountField();
		
	}*/
	

	@Test(priority = 2)
	public void VerifyInvalidDiscountCode(){
		orderPage.clickOnDiscountField();
		String msg = orderPage.verifyInvalidDiscountCode(prop.getProperty("invaliddiscountcode"));
		String expectedMsg = "* Oops. Invalid discount code "+"\""+prop.getProperty("invaliddiscountcode")+"\"";
		Assert.assertEquals(msg,expectedMsg);
		
	}
	
	@Test(priority = 3)
	public void VerifyvalidDiscountCodeandcheckout(){
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String discCheck = orderPage.verifyvalidDiscountCode(prop.getProperty("validdiscountcode"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(discCheck);
		String expectedCodeMsg = prop.getProperty("validdiscountcode")+":";
		Assert.assertEquals(discCheck,expectedCodeMsg);
		System.out.println(expectedCodeMsg);
		ordersumpage = orderPage.checkout();
		
		System.out.println("Before SS");
		testUtil.screenShot();
		System.out.println("After SS");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		orderPage.clearingtheAppliedDiscount();
	}
	
	
	@AfterClass
	public void tearDown()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.quit();
	}
	
}
