package com.hirestreet.qa.testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hirestreet.qa.base.TestBase;
import com.hirestreet.qa.pages.AccountPage;
import com.hirestreet.qa.pages.LoginPage;
import com.hirestreet.qa.pages.OrderPage;

public class AccountPageTest extends TestBase{
	LoginPage loginPage;
	AccountPage accountPage;
	OrderPage orderPage;
	
	public AccountPageTest()
	{
		super();
	}
	
	@BeforeClass
	public void setUp()
	{
		initialization();
		loginPage  = new LoginPage();
		accountPage = loginPage.login(prop.getProperty("email"), prop.getProperty("password"));
		
	}
	
	@Test
	public void verifyBasketLinkTest()
	{
		orderPage = accountPage.clickOnBasketLink();
	}
	
	
	
	@AfterClass
	public void tearDown()
	{
		driver.quit();
	}

}
