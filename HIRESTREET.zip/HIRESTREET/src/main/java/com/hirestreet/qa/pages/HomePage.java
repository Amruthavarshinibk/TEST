package com.hirestreet.qa.pages;

public class HomePage {
	

}
